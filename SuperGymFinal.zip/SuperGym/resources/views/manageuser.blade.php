<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="{{url('css/manageuser.css')}}">

</head>
<body>
    @if(Auth::check())

    <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" id="navtop">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <a class="navbar-brand"><img src="https://images.cooltext.com/5569985.png" alt=""></a>
          <ul class="navbar-nav">
              <li class="nav-item active">
                  <a class="nav-link" href="/dashboardadmin">Account</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="/equipmentadmin">Equipments</a>
                </li>
              @auth

              <li class="nav-item dropdown" id="drop">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  {{auth()->user()->name}}
                </a>
                <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                  <li><a class="dropdown-item" href='/insert'>Insert Product</a></li>
                  <li><a class="dropdown-item" href='/manageuser'>Manage User</a></li>
                  <li><a class="dropdown-item" href="/logout">Log Out</a></li>
                </ul>
              </li>

                    @endauth
            </ul>


        </div>
    </nav>
    @if(Session::has('success'))
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{Session::get('success')}}
        </div>
    @elseif(Session::has('failed'))
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{Session::get('failed')}}
        </div>
     @endif

    <table class="table">
        <thead class="table-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
                @foreach ($users as $u)
                <form action="/delete/{{$u->id}}" method="post">
                    @csrf
                    @method('delete')
              <tr>
                <td>{{$u->id}}</td>
                <td>{{$u->name}}</td>
                <td>
                    <button type="submit" class="btn-danger">Delete</button>

                </td>
              </tr>
            </form>
              @endforeach


            </tbody>
          </table>
    </div>

        {{Session::get('session')}}
    @else

        @endif

    </body>
    </html>
