<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Update</title>
    <link rel="stylesheet" type="text/css" href="{{url('css/update.css')}}">

</head>
<body>
    @if(Auth::check())

    <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" id="navtop">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <a class="navbar-brand"><img src="https://images.cooltext.com/5569985.png" alt=""></a>
          <ul class="navbar-nav">
              <li class="nav-item active">
                  <a class="nav-link" href="/dashboardadmin">Account</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="/equipmentadmin">Equipments</a>
                </li>
              @auth

              <li class="nav-item dropdown" id="drop">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  {{auth()->user()->name}}
                </a>
                <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                  <li><a class="dropdown-item" href='/insert'>Insert Product</a></li>
                  <li><a class="dropdown-item" href='/manageuser'>Manage User</a></li>
                  <li><a class="dropdown-item" href="/logout">Log Out</a></li>
                </ul>
              </li>

                    @endauth
            </ul>


        </div>
    </nav>

    <div class="container mt-5" id="bot">
        <form action="/updateproduct" method="POST" id="insertform" enctype="multipart/form-data">
            @csrf
            @method('put')
            <div class="row" id="bot">
                <div class="col-xl-6 m-auto">
                    <div class="card shadow" id="upform">
                        @if(Session::has('success'))
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                {{Session::get('success')}}
                            </div>
                        @elseif(Session::has('failed'))
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                {{Session::get('failed')}}
                            </div>
                        @endif
                        <div class="card-header">
                            <h4 class="card-title font-weight-bold"> Update Product </h4>
                        </div>

                        <div class="card-body">
                            <div class="form-group">
                                <label for="title"> Name </label>
                                    <input type="text" name="title" class="form-control" value="{{old('title')}}" />
                                    {!!$errors->first("title", "<span class='text-danger'>:message</span>")!!}
                            </div>

                            <div class="form-group">
                                <label for="description"> Description </label>
                                <textarea name="description" form="insertform" style="resize: none;" rows="2" cols="50" placeholder="Enter text here..."></textarea>
                                {!!$errors->first("description", "<span class='text-danger'>:message</span>")!!}

                            </div>

                            <div class="form-group">
                                <label for="price"> Price </label>
                                    <input type="text" name="price" class="form-control" value="{{old('price')}}" />
                                    {!!$errors->first("price", "<span class='text-danger'>:message</span>")!!}
                            </div>

                            <div class="form-group">
                                <label for="stock"> Stock </label>
                                    <input type="text" name="stock" class="form-control" value="{{old('stock')}}" />
                                    {!!$errors->first("stock", "<span class='text-danger'>:message</span>")!!}
                            </div>

                            <div class="form-group">
                                <label for="image"> Image </label>
                                    <input type="file" name="image" class="form-control" />
                                    {!!$errors->first("image", "<span class='text-danger'>:message</span>")!!}
                            </div>


                            </div>
                            <div class="card-footer" id="cardbot">
                                <button type="submit" class="btn btn-success"> Submit </button>
                                <input type="hidden" value="{{$products->id}}" name="productid">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </form>
    </div>

    </div>

        {{Session::get('session')}}
    @else

        @endif
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
    </html>
