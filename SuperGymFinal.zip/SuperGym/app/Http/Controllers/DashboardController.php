<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function viewhome(){
        return view('home');
    }

    public function menu(){
        return view('dashboard');
    }

    public function menuadmin(){
        return view('dashboardadmin');
    }

    public function create(){
        return view('create');
    }

    public function store(Request $req){

        $validated = $req->validate([
            'image'     =>'image|file|max:10000'
        ]);

        if($req->file('image')){
            $validated['image'] = $req->file('image')->store('post-images');
        }
    }
}
