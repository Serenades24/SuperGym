<?php

namespace App\Http\Controllers;

use App\Models\Detail;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class InsertController extends Controller
{
    public function viewinsert(){
        return view('insert');
    }

    public static function insert(Request $request){
        $lastid=Product::pluck('id')->last();
       $validated= $request->validate([
            'title'         => 'min:5|max:25|string|required',
            'description'   => 'min:10|max:100|string|required',
            'price'         => 'gte:1000|lte:10000000|required',
            'stock'         => 'gte:1|required',
            'image'         => 'required'
        ]);
        $file=$request->file('image');
        $filename=$file->getClientOriginalName();
        Storage::putFileAs('public/images',$file,$filename);
        $filepath='storage/images/'.$filename;
        $produk = new Product;
        $detil = new Detail;
        $newid=$lastid+1;
        $produk->id=$newid;
        $detil->id=$newid;
        $detil->product_id=$newid;
        $produk->name=$validated['title'];
        $detil->description=$validated['description'];
        $detil->price=$validated['price'];
        $produk->stock=$validated['stock'];
        $detil->image=$filepath;
        $produk->save();
        $detil->save();

        return redirect()->back()->with('success', 'Insert Successfull');



    }
}
