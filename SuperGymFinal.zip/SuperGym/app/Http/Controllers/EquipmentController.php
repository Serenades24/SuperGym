<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Database\Seeders\ProductSeeder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EquipmentController extends Controller
{
    public static function viewequipment(){
        $count=DB::table('products')->count();

        if($count>4){
            return view('equipment', ['products'=> Product::paginate(4)]);
        }
        else{
            return view('equipment', ['products'=> Product::paginate(9999)]);
        }

    }

    public static function viewequipmentadmin(){
        $count=DB::table('products')->count();

        if($count>4){
            return view('equipmentadmin', ['products'=> Product::paginate(4)]);
        }
        else{
            return view('equipmentadmin', ['products'=> Product::paginate(9999)]);
        }

    }
}
