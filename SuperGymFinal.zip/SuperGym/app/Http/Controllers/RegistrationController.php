<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class RegistrationController extends Controller
{
    public function regis(){
        return view('registration');
    }

    public function store(Request $req){
       $validated = $req->validate(
            [
                'name'        =>    'required|string|min:3',
                'age'         =>    'integer|gte:10|lte:100',
                'address'     =>    'string|min:10|max:255',
                'phone'       =>    'numeric|min:9',
                'email'       =>    'email|unique:users,email',
                'password'    =>    'alpha_num|min:6',
                'confirm_password'    =>    'required|same:password'

            ]
         );
         $validated['password'] = Hash::make($validated['password']);

        User::create($validated);


        return redirect('/login')->with('success', 'Registration Successfull');
    }
}
