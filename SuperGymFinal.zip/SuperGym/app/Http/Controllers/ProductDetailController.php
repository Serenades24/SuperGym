<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductDetailController extends Controller
{
    public static function viewproductdetail($id){
        $itemid=Product::Where('id',$id)->first();

        return view('productdetail',['products'=>$itemid]);
    }

    public static function viewproductdetailadmin($id){
        $itemid=Product::Where('id',$id)->first();

        return view('productdetailadmin',['products'=>$itemid]);
    }
}
