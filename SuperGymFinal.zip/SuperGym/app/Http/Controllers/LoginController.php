<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;

class LoginController extends Controller
{
    public function log(){
        return view('login');
    }

    public function authenticate(Request $req){

      $credential =  $req->validate([
            'email'     => 'required|email',
            'password'  => 'required'
        ]);

        if($req->remember){
            Cookie::queue('email',$credential['email'],60);
            Cookie::queue('password',$credential['password'],60);
        }

        if(Auth::attempt($credential, true)){
            if(Auth::user()->role=='admin'){
                return redirect('/dashboardadmin');
            }
            else{
                return redirect('/dashboard');
            }
        }

        return back()->with('loginerror', 'Login Failed');

    }

    public function logout(){
        Auth::logout();
        return redirect('/login');
    }
}
