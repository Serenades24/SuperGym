<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public static function viewtransaction(){
        return view('transaction',['transactions'=>Transaction::all()]);
    }

}
