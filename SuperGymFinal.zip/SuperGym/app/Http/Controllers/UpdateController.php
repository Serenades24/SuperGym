<?php

namespace App\Http\Controllers;

use App\Models\Detail;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UpdateController extends Controller
{
    public function viewupdate($id){
        $itemid=Product::Where('id',$id)->first();
        return view('update', ['products'=>$itemid]);
    }

    public function update(Request $request){
        $validated= $request->validate([
            'title'         => 'min:3|max:50|string|required',
            'description'   => 'min:10|max:1000|string|required',
            'price'         => 'gte:10000|lte:10000000|required',
            'stock'         => 'gte:1|required',
            'image'         => 'image'
        ]);

        $id=$request->productid;
         $find = Product::find($id);
         $find2 = Detail::find($id);

        $file=$request->file('image');
        if($file!=null){

            $filename=$file->getClientOriginalName();
            Storage::putFileAs('public/images',$file,$filename);
            $filepath='storage/images/'.$filename;

            Storage::delete($find2->image);
            $find2->image=$filepath;
        }
        else{
            $find2->image=$find2->image;
        }
        if($validated['title']!=null){
            $find->name=$validated['title'];
        }
        else{
            $find->name=$find->name;
        }
        if($validated['description']!=null){
            $find2->description=$validated['description'];
        }
        else{
            $find2->description=$find2->description;
        }
        if($validated['price']!=null){
            $find2->price=$validated['price'];
        }
        else{
            $find2->price=$find2->price;
        }
        if($validated['stock']!=null){
            $find->stock=$validated['stock'];
        }
        else{
            $find->stock=$find->stock;
        }

        $find->save();
        $find2->save();
        return redirect()->back()->with('success', 'Update Successfull');
    }

}
