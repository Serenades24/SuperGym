<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    public static function viewcart(){
        return view('cart',['carts'=>Cart::all()]);
    }

    public static function deletecart($id){
        $find=Cart::find($id);

        $find->delete();
        return redirect()->back();

    }

    public static function insertcart(Request $request){

        $newcart = new Cart;
        $newcart->name=$request->productname;
        $newcart->price=$request->productprice;
        $newcart->quantity=$request->quantity;
        $newcart->description=$request->productdes;
        $newcart->subtotal=(($request->quantity)*($request->productprice));
        $id=$request->productid;
        $find = Product::find($id);
        $find->stock=(($find->stock)-($request->quantity));

        $newcart->save();
        $find->save();
        return redirect()->back()->with('success', 'Item successfully added');
    }

    public static function checkout(Request $request){

        $currentdate = \Carbon\Carbon::now()->toDateTimeString();

        $newtrans = new Transaction;
        $newtrans->time=$currentdate;
        $newtrans->save();

        DB::table('cart')->delete();


        return redirect()->back()->with('success', 'Checkout Successfull');
    }
}
