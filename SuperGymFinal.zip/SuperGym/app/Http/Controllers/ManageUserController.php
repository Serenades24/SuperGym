<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class ManageUserController extends Controller
{
    public function viewmanage(){
        return view('manageuser',['users'=>User::all()]);
    }

    public function destroy($id){
        $find=User::find($id);

        $find->delete();
        return redirect()->back();
    }
}
