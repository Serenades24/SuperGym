<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UpdateProfileController extends Controller
{
    public function viewupdateprofile($id){
        $userid=User::Where('id',$id)->first();
        return view('updateprofile', ['users'=>$userid]);
    }

    public function updateprofile(Request $request){
        $validated= $request->validate([
            'name'        =>    'required|string|min:3',
            'age'         =>    'integer|gte:10|lte:100',
            'address'     =>    'string|min:10|max:255',
            'phone'       =>    'numeric|min:9',
            'password'    =>    'alpha_num|min:6',
        ]);

        $validated['password'] = Hash::make($validated['password']);
        $id=$request->userid;
        $find = User::find($id);

        if($validated['name']!=null){
            $find->name=$validated['name'];
        }
        else{
            $find->name=$find->name;
        }

        if($validated['password']!=null){
            $find->password=$validated['password'];
        }
        else{
            $find->password=$find->password;
        }

        if($validated['age']!=null){
            $find->age=$validated['age'];
        }
        else{
            $find->age=$find->age;
        }

        if($validated['address']!=null){
            $find->address=$validated['address'];
        }
        else{
            $find->address=$find->address;
        }

        if($validated['phone']!=null){
            $find->phone=$validated['phone'];
        }
        else{
            $find->phone=$find->phone;
        }

        $find->save();
        return redirect()->back()->with('success', 'Update Successfull');

    }


}
