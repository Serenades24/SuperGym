<?php

use App\Http\Controllers\CartController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EquipmentController;
use App\Http\Controllers\GoogleController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InsertController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ManageUserController;
use App\Http\Controllers\ProductDetailController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\UpdateController;
use App\Http\Controllers\UpdateProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [DashboardController::class, 'viewhome']);
Route::get('/home', [DashboardController::class, 'viewhome']);
Route::get('/registration', [RegistrationController::class, 'regis'])->middleware('guest');
Route::post('/registration/regis', [RegistrationController::class, 'store']);

Route::get('/login', [LoginController::class, 'log'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::get('/logout', [LoginController::class, 'logout']);

Route::get('/dashboard', [DashboardController::class, 'menu'])->middleware('auth');
Route::post('/dashboard/create', [DashboardController::class, 'store']);
Route::get('/equipment', [EquipmentController::class, 'viewequipment'])->middleware('auth');
Route::get('/productdetail/{id}',[ProductDetailController::class, 'viewproductdetail'])->middleware('auth');
Route::get('/updateprofile/{id}', [UpdateProfileController::class,'viewupdateprofile'])->middleware('auth');
Route::put('/updateprofile',[UpdateProfileController::class, 'updateprofile'])->middleware('auth');
Route::get('/cart', [CartController::class,'viewcart'])->middleware('auth');
Route::post('/cart/checkout', [CartController::class,'checkout'])->middleware('auth');
Route::post('/product/buy', [CartController::class,'insertcart'])->middleware('auth');
Route::delete('/deletecart/{id}', [CartController::class,'deletecart'])->middleware('auth');
Route::get('/transaction', [TransactionController::class, 'viewtransaction'])->middleware('auth');
Route::get('/dashboardadmin', [DashboardController::class, 'menuadmin'])->middleware('admin');
Route::get('/update/{id}', [UpdateController::class,'viewupdate'])->middleware('admin');
Route::put('/updateproduct',[UpdateController::class, 'update'])->middleware('admin');
Route::get('/equipmentadmin', [EquipmentController::class, 'viewequipmentadmin'])->middleware('admin');
Route::get('/productdetailadmin/{id}',[ProductDetailController::class, 'viewproductdetailadmin'])->middleware('auth');
Route::get('/insert', [InsertController::class,'viewinsert'])->middleware('admin');
Route::post('/product/insert', [InsertController::class,'insert'])->middleware('admin');
Route::get('/manageuser', [ManageUserController::class,'viewmanage'])->middleware('admin');
Route::delete('/delete/{id}', [ManageUserController::class,'destroy'])->middleware('admin');
