<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/home.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href='http://fonts.googleapis.com/css?family=Oxygen:400,300' rel='stylesheet' type='text/css'>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <title>Super GYM</title>
</head>
<body>
    <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" id="navtop">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <a class="navbar-brand"><img src="https://images.cooltext.com/5569985.png" alt=""></a>
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="#home">Home</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#carouselExampleIndicators">About Us</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#contact">Contact</a>
            </li>
          </ul>
        </div>
    </nav>

    <div class="background" id="home">
        <div class="centered">
            <div class="logo1">
                <img src="/image/supergym1.png" alt="">
            </div>
            <div class="title">
                Welcome!
                <br/>
                How can I help you?
                <br/>
            </div>
            <div class="wrap-row">
                <div class="spacing">
                    <button type="button" class="rounded-pill"><a href="/login" class="link-light">Login</a></button>
                </div>
                <div class="spacing">
                    <button type="button" class="rounded-pill"><a href="/registration" class="link-light">Register</a></button>
                </div>
            </div>
        </div>
    </div>

            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="image/equipment.jpg" alt="First slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>International Standard Equipment</h5>
                            <p>We have full international standard gym equipment</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="image/trainer.jpg" alt="Second slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>International Graded Trainer</h5>
                            <p>Our trainers have international training certificate</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="image/clean.jpg" alt="Third slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Fully Cleaned and Sterilized Equipment</h5>
                            <p>Our equipment well maintained and cleaned regularly</p>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

            <div class="contactus" id="contact">
                <div class="logo2">
                    <img src="https://media.giphy.com/media/UNhtrz29uIC3a4KBAx/giphy.gif" alt="">
                </div>

                <div class="detail">

                    <div class="address">
                        <img src="/image/address.png" class="img-fluid" alt="">
                        <div class="addressdetail">
                            <h3>Sisingamangajara 24 Cirebon Jawa Barat</h3>
                        </div>
                    </div>

                    <div class="phone">
                        <img src="/image/phone.png" class="img-fluid" alt="">
                        <div class="phonedetail">
                            <h3>0231-201234</h3>
                        </div>
                    </div>

                    <div class="media">
                        <div class="instagram">
                            <img src="/image/instagram.png" class="img-fluid" alt="">
                            <div class="instadetail">
                                <h3>SuperGYM</h3>
                            </div>
                        </div>

                        <div class="whatsapp">
                            <img src="/image/whatsapp.png" class="img-fluid" alt="">
                            <div class="whatsappdetail">
                                <h3>08123456789</h3>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

</body>
</html>
<?php /**PATH E:\Kuliah\Semester 5\Web Programming\project2\SuperGym\resources\views/home.blade.php ENDPATH**/ ?>