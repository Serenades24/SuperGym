<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Product Detail</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/productdetail.css')); ?>">

</head>
<body>
    <?php if(Auth::check()): ?>
    <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" id="navtop">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <a class="navbar-brand"><img src="https://images.cooltext.com/5569985.png" alt=""></a>
          <ul class="navbar-nav">
              <li class="nav-item active">
                  <a class="nav-link" href="/dashboardadmin">Account</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="/equipmentadmin">Equipments</a>
                </li>
              <?php if(auth()->guard()->check()): ?>

              <li class="nav-item dropdown" id="drop">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <?php echo e(auth()->user()->name); ?>

                </a>
                <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                  <li><a class="dropdown-item" href='/insert'>Insert Product</a></li>
                  <li><a class="dropdown-item" href='/manageuser'>Manage User</a></li>
                  <li><a class="dropdown-item" href="/logout">Log Out</a></li>
                </ul>
              </li>

                    <?php endif; ?>
            </ul>


        </div>
    </nav>

    <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php elseif(Session::has('failed')): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <?php echo e(Session::get('failed')); ?>

                            </div>
                        <?php endif; ?>
        <div class="productdetail">
            <img src="<?php echo e(url(''.$products->detail->image)); ?>" class="card-img-top" alt="...">

                <div class="detail">
                    <h4 class="name"><?php echo e($products->name); ?></h4>
                    <h5 class="descrip">Description: </h5>
                    <h6 class="description"><?php echo e($products->detail->description); ?></h6>
                    <h5 class="stck">Stocks: </h5>
                    <h6 class="stock"><?php echo e($products->stock); ?></h6>
                    <h5 class="prc">Price: </h5>
                    <h6 class="price">Rp. <?php echo e($products->detail->price); ?></h6>

                </div>

        </div>

        <?php echo e(Session::get('session')); ?>

    <?php else: ?>

        <?php endif; ?>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
    </html>
<?php /**PATH E:\Kuliah\Semester 5\Web Programming\project2\SuperGym\resources\views/productdetailadmin.blade.php ENDPATH**/ ?>