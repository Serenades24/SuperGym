<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            ['id' => 1, 'name' => "Dumbell 2 KG", 'stock' => 50],
            ['id' => 2, 'name' => "Skipping Rope", 'stock' => 60],
            ['id' => 3, 'name' => "Kettlebell 5 KG", 'stock' => 45],
            ['id' => 4, 'name' => "Bola Fitness", 'stock' => 50],
        ]);
    }
}
