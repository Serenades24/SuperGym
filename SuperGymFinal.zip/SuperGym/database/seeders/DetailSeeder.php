<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('details')->insert([
            ['id' => 1, 'product_id' => 1, 'description' => "Dumbell 2 KG kualitas tinggi", 'price' => 100000, 'image' => "storage\image\dumbell.jpg"],
            ['id' => 2, 'product_id' => 2, 'description' => "Skipping rope kualitas tinggi", 'price' => 50000, 'image' => "storage\image\skippingrope.png"],
            ['id' => 3, 'product_id' => 3, 'description' => "Kettlebell 5 KG kualitas tinggi", 'price' => 200000, 'image' => "storage\image\kettlebell.jpg"],
            ['id' => 4, 'product_id' => 4, 'description' => "Bola fitness kualitas tinggi", 'price' => 70000, 'image' => "storage\image\ball.jpg"],
        ]);
    }
}
