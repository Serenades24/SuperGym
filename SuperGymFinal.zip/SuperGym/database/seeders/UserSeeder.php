<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'name' => 'admin',
                'age'  => '30',
                'address' => 'Jalan abc no 1 Jakarta Utara',
                'phone' => '08123123123',
                'email' => 'admin123@gmail.com',
                'password' => Hash::make('admin123'),
                'role' =>'admin',
            ],
            [
                'name' => 'user1',
                'age'  => '25',
                'address' => 'Jalan abc no 2 Jakarta Utara',
                'phone' => '081111111111',
                'email' => 'user1@gmail.com',
                'password' => Hash::make('user1111'),
                'role' =>'user',
            ],

        ]);
    }
}
